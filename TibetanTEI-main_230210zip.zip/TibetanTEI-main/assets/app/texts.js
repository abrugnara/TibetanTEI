const texts = [
  { id: "1_gompopa", url: "content/1_gompopa.xml" },
  { id: "2_dignaga", url: "content/2_dignaga.xml" },
  { id: "3", url: "content/3_ganden.xml" },
  { id: "4", url: "content/4_shrisena.xml" },
];

const references = [
  {
    type: "BUDA",
    url: "https://library.bdrc.io/show/bdr:",
  },
  {
    type: "DOHO",
    url: "https://library.bdrc.io/show/bdr:",
  },
  {
    type: "SRS",
    url: "",
  },
  {
    type: "rKTs",
    url: "",
  },
];
